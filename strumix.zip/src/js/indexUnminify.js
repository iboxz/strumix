gsap.registerPlugin(ScrollTrigger, ScrollSmoother, SplitText);
let Smoother = null;
async function initializeTriggers() {
  if (window.innerWidth >= 769) {
    await new Promise((e) => setTimeout(e, 400));
    let e = gsap.utils.toArray(".hero, .section3, .section4, .sectionBlogs, .noPinSection");
    e.forEach((t, r) => {
      let o = null;
      r < 4
        ? (o = ScrollTrigger.create({
            trigger: t,
            start: "top top",
            pin: !0,
            pinSpacing: !1,
            onUpdate(e) {
              -1 === e.direction ? (t.style.borderRadius = "") : (t.style.borderRadius = "0");
            },
          }))
        : 4 === r &&
          (o = ScrollTrigger.create({
            trigger: t,
            start: "top top",
            endTrigger: e[r - 1],
            end: "top top",
            pin: !0,
            pinSpacing: !1,
            onUpdate(e) {
              -1 === e.direction ? (t.style.borderRadius = "") : (t.style.borderRadius = "0");
            },
          }));
    });
  }
}
(Smoother = ScrollSmoother.create({ wrapper: "#smooth-wrapper", content: "#smooth-content", smooth: 0.8, effects: !0, smoothTouch: !1 })),
  "ontouchstart" in window ||
    (window.addEventListener("resize", () => {
      window.innerWidth !== window.__pw && location.reload();
    }),
    (window.__pw = window.innerWidth)),
  initializeTriggers();
const vh100 = window.innerHeight;
window.innerWidth >= 769
  ? gsap.to(".hero .background", {
      scrollTrigger: { trigger: ".section3", start: `-${vh100 / 2} 90%`, end: `-${vh100 / 2} 50%`, scrub: 1 },
      inset: "0vmin",
      height: "calc(100vh - 0vmin)",
      duration: 1,
      marginTop: "0vmin",
      borderRadius: "0vmin",
    })
  : gsap.to(".hero .background", {
      scrollTrigger: { trigger: ".section3", start: `-${vh100 / 10} 90%`, end: `-${vh100 / 10} 50%`, scrub: 1 },
      inset: "0vmin",
      height: "calc(100vh - 0vmin)",
      duration: 1,
      marginTop: "0vmin",
      borderRadius: "0vmin",
    });
const container = document.querySelector(".hero .titleSide"),
  maxRotate = 3;
document.addEventListener("mousemove", (e) => {
  let t = (e.clientX / window.innerWidth - 0.007) * 2,
    r = (e.clientY / window.innerHeight - 0.003) * 2,
    o = 3 * t,
    i = -(3 * r);
  gsap.to(container, { rotationX: i, rotationY: o, transformPerspective: 800, ease: "power1.out", duration: 0.4 });
}),
  gsap.to("#sceneHolder", {
    scrollTrigger: { trigger: ".section3", start: "top top", toggleActions: "play none none reset" },
    display: "none",
    visibility: "hidden",
  }),
  gsap.from(".section3 div:nth-child(1) img", {
    scrollTrigger: { trigger: ".section3", start: "top center", end: "top top", scrub: 4 },
    scale: "1.1",
  }),
  gsap.to(".section3 .textSide .hr", { scrollTrigger: { trigger: ".section3", start: "60% bottom", end: "60% top", scrub: 4 }, width: "100%" }),
  navigator.userAgent.match(/iPhone/i) ||
    gsap.from(new SplitText(".section3 .textSide h2", { type: "chars", tagName: "span", tag: "span" }).chars, {
      scrollTrigger: { trigger: ".section3 .textSide h2", start: "40% bottom", end: "40% top", toggleActions: "play none none reset" },
      delay: 0.5,
      opacity: 0.2,
      ease: "power3.out",
      stagger: 0.15,
    }),
  navigator.userAgent.match(/iPhone/i) ||
    gsap.from(new SplitText(".section4 h3", { type: "chars", tagName: "span", tag: "span" }).chars, {
      scrollTrigger: { trigger: ".section4 h3", start: "40% bottom", end: "40% top", toggleActions: "play none none reset" },
      delay: 0.5,
      opacity: 0.3,
      ease: "power3.out",
      stagger: 0.15,
    }),
  gsap.to(".section4 h3 > #line", { scrollTrigger: { trigger: ".section4 h3", start: "40% bottom", end: "40% top", scrub: 4 }, width: "15vmin" });
const productImg = document.getElementById("productImg"),
  windowWidth = window.innerWidth,
  imgWidth = productImg.offsetWidth,
  centerX = windowWidth / 2 - imgWidth / 3;
gsap.set(productImg, { xPercent: -50, yPercent: -50, transformOrigin: "center", left: centerX + "px" });
const followMouse = (e) => {
  let t = e.clientX,
    r = e.clientY,
    o = t - centerX;
  gsap.to(productImg, { duration: 1, ease: "power3", x: 0.3 * o }), gsap.to(productImg, { duration: 1, ease: "power3", y: r });
  let i = `polygon(
${(t / window.innerWidth) * 10}% 0%,
${100 - (r / window.innerHeight) * 10}% 0%,
${100 - (t / window.innerWidth) * 10}% 100%,
${(r / window.innerHeight) * 10}% 100%)`;
  gsap.to(productImg, { duration: 1, ease: "power3", clipPath: i });
};
document.addEventListener("mousemove", followMouse);
const products = {
    concreteAdditive: "struproof-hp.jpg",
    constructionChemicals: "strutop-rm450.jpg",
    waterstop: "struswell.jpg",
    "modern-building-facades": "strusin-concrete2.jpg",
    "plastic-spacers": "plastic-spacers.jpg",
    "raw-materials": "Strumin-gel4.jpg",
  },
  section4 = document.querySelector(".section4"),
  boxes = section4.querySelectorAll("div:not(:first-child):not(:last-child)");
boxes.forEach((e) => {
  e.addEventListener("mouseover", function () {
    (productImg.style.opacity = "1"),
      (productImg.style.filter = "blur(0)"),
      (productImg.innerHTML = `<img src="assets/productImg/${products[e.id]}" alt="" />`);
  }),
    e.addEventListener("mouseout", function () {
      (productImg.style.opacity = "0"), (productImg.style.filter = "blur(5vmin)");
    }),
    e.addEventListener("click", function () {
      let e = this.id,
        t = `products/?productID=${e}`;
      window.location.href = t;
    });
}),
  navigator.userAgent.match(/iPhone/i) ||
    gsap.from(new SplitText(".sectionBlogs h3", { type: "chars", tagName: "span", tag: "span" }).chars, {
      scrollTrigger: { trigger: ".sectionBlogs h3", start: "40% bottom", end: "40% top", toggleActions: "play none none reset" },
      delay: 0.5,
      opacity: 0.3,
      ease: "power3.out",
      stagger: 0.15,
    }),
  gsap.to(".sectionBlogs h3 > #line", {
    scrollTrigger: { trigger: ".sectionBlogs h3", start: "40% bottom", end: "40% top", scrub: 4 },
    width: "15vmin",
  }),
  gsap.to(".section5 > div", { scrollTrigger: { trigger: ".section5", start: "top center", end: "bottom center", scrub: 2 }, y: "100%" });
let loops = gsap.utils.toArray(".section5 .infiniteScrollText div").map((e, t) => {
    let r = e.querySelectorAll(".section5  .infiniteScrollText div span");
    return horizontalLoop(r, {
      repeat: -1,
      speed: 1.5 + 0.5 * t,
      reversed: !1,
      paddingRight: parseFloat(gsap.getProperty(r[0], "marginRight", "px")),
    });
  }),
  currentScroll = 0,
  scrollDirection = 1;
function horizontalLoop(e, t) {
  (e = gsap.utils.toArray(e)), (t = t || {});
  let r = gsap.timeline({
      repeat: t.repeat,
      paused: t.paused,
      defaults: { ease: "none" },
      onReverseComplete: () => r.totalTime(r.rawTime() + 100 * r.duration()),
    }),
    o = e.length,
    i = e[0].offsetLeft,
    n = [],
    s = [],
    c = [],
    a = 0,
    l = 100 * (t.speed || 1),
    g = !1 === t.snap ? (e) => e : gsap.utils.snap(t.snap || 1),
    d,
    p,
    $,
    u,
    h,
    m;
  for (
    gsap.set(e, {
      xPercent(e, t) {
        let r = (s[e] = parseFloat(gsap.getProperty(t, "width", "px")));
        return (c[e] = g((parseFloat(gsap.getProperty(t, "x", "px")) / r) * 100 + gsap.getProperty(t, "xPercent"))), c[e];
      },
    }),
      gsap.set(e, { x: 0 }),
      d =
        e[o - 1].offsetLeft +
        (c[o - 1] / 100) * s[o - 1] -
        i +
        e[o - 1].offsetWidth * gsap.getProperty(e[o - 1], "scaleX") +
        (parseFloat(t.paddingRight) || 0),
      m = 0;
    m < o;
    m++
  )
    (h = e[m]),
      (p = (c[m] / 100) * s[m]),
      (u = ($ = h.offsetLeft + p - i) + s[m] * gsap.getProperty(h, "scaleX")),
      r
        .to(h, { xPercent: g(((p - u) / s[m]) * 100), duration: u / l }, 0)
        .fromTo(h, { xPercent: g(((p - u + d) / s[m]) * 100) }, { xPercent: c[m], duration: (p - u + d - p) / l, immediateRender: !1 }, u / l)
        .add("label" + m, $ / l),
      (n[m] = $ / l);
  function _(e, t) {
    (t = t || {}), Math.abs(e - a) > o / 2 && (e += e > a ? -o : o);
    let i = gsap.utils.wrap(0, o, e),
      s = n[i];
    return (
      s > r.time() != e > a && ((t.modifiers = { time: gsap.utils.wrap(0, r.duration()) }), (s += r.duration() * (e > a ? 1 : -1))),
      (a = i),
      (t.overwrite = !0),
      r.tweenTo(s, t)
    );
  }
  return (
    (r.next = (e) => _(a + 1, e)),
    (r.previous = (e) => _(a - 1, e)),
    (r.current = () => a),
    (r.toIndex = (e, t) => _(e, t)),
    (r.times = n),
    t.reversed && (r.vars.onReverseComplete(), r.reverse()),
    r
  );
}
window.addEventListener("scroll", () => {
  let e = window.pageYOffset > currentScroll ? 1 : -1;
  e !== scrollDirection &&
    (loops.forEach((t) => {
      gsap.to(t, { timeScale: e, overwrite: !0 });
    }),
    (scrollDirection = e)),
    (currentScroll = window.pageYOffset);
}),
  gsap.to(".section6 > div #line", {
    scrollTrigger: { trigger: ".section6 > div:first-child", start: "40% bottom", end: "40% top", scrub: 4 },
    width: "15vmin",
  }),
  gsap.from(CSSRulePlugin.getRule(".section7::before"), {
    scrollTrigger: { trigger: ".section7", start: "top center", end: "top top", scrub: 4 },
    backgroundSize: "200% auto",
  });
const today = new Date(),
  version = `${today.getFullYear()}${(today.getMonth() + 1).toString().padStart(2, "0")}${today.getDate().toString().padStart(2, "0")}`;
fetch(`../serverAssets/blogs.json?version=${version}`)
  .then((e) => e.json())
  .then((e) => {
    let t = e.blogs;
    t.sort((e, t) => new Date(t.dateConvert) - new Date(e.dateConvert));
    let r = t.slice(0, 4),
      o = "";
    r.forEach((e, t) => {
      o += `
        <a class="cards" href="./blogs/${e.url}" data-cursor="pointerLinkNavbar">
          <div>
            <h4>
              <span>${e.title}</span>
            </h4>
            ${0 === t ? `<img src="./serverAssets/blogsCoverImg/${e.image}" alt="${e.title} تصویر مقاله" />` : ""}
            <p>
              ${e.description}
            </p>
          </div>
        </a>
      `;
    }),
      (o += `
      <a class="cards" href="./blogs/" data-cursor="pointerLinkNavbar">
        <div>
          <p>لیست تمام مقالات</p>
          <img src="assets/VectorFlesh7.svg" alt="flesh Icon" />
        </div>
      </a>
    `),
      (document.querySelector(".body").innerHTML = o),
      activateCustomCursors();
  })
  .catch((e) => console.error("Error fetching data:", e));
