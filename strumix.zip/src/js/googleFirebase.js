const firebaseConfig = {
  apiKey: "AIzaSyAP-PytVZKr7iK3fUb2TqTRtq19plpbCkU",
  authDomain: "strumix-ea191.firebaseapp.com",
  projectId: "strumix-ea191",
  storageBucket: "strumix-ea191.appspot.com",
  messagingSenderId: "780526508875",
  appId: "1:780526508875:web:4d65e81e3bf5151549e6ce",
  measurementId: "G-VLF9HZW78X",
};
firebase.initializeApp(firebaseConfig);
